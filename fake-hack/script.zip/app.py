import time
import webbrowser

url = "https://rmbi.ch/vital/donation"


while True:
    time.sleep(20)
    webbrowser.open(url)