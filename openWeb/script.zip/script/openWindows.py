import time
import webbrowser


while True:
    time.sleep(300)
    webbrowser.open("https://rmbi.ch/vital/donation")